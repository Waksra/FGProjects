#include "Engine.h"
#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

int WinMain(HINSTANCE, HINSTANCE, char*, int)
{
	engInit();

	while(engBeginFrame())
	{
		engSetColor(0x222222FF);
		engClear();

#if SERVER

		engSetColor(rand(), rand(), rand(), 0xFF);
		engText(50, 50, "SERVER WHOOO!!!");

#else

		engSetColor(0xCCCCCCFF);
		engText(50, 50, "Client... :(");

#endif
	}

	return 0;
}